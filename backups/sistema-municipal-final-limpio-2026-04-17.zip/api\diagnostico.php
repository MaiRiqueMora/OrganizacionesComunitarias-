<?php

/**
 * Sistema Municipal de Organizaciones
 * 
 * ARCHIVO: diagnostico.php
 * 
 * DESCRIPCIÓN:
 * Script de diagnóstico completo del sistema y base de datos.
 * Herramienta de verificación de estado e integridad del sistema.
 * 
 * FUNCIONALIDADES:
 * - Verificación de conexión a base de datos
 * - Listado de todas las tablas existentes
 * - Validación de estructura de tablas críticas
 * - Conteo de registros por tabla
 * - Detección de problemas de instalación
 * - Diagnóstico de integridad de datos
 * - Verificación de permisos y accesos
 * 
 * DIAGNÓSTICOS REALIZADOS:
 * - Conexión SQLite y existencia de BD
 * - Presencia de tablas esenciales (organizaciones, usuarios, etc.)
 * - Conteo de registros para verificar datos
 * - Estructura de tablas y columnas
 * - Estado general del sistema
 * 
 * USO:
 * - Herramienta de diagnóstico rápido
 * - Verificación post-instalación
 * - Soporte técnico y troubleshooting
 * - Acceso sin autenticación (herramienta de sistema)
 * - Para uso del equipo de TI y desarrolladores
 * 
 * SALIDA JSON:
 * - ok: true/false - Estado general del sistema
 * - tablas: Array con nombres de tablas existentes
 * - registros: Array con conteo por tabla
 * - errores: Array con problemas detectados
 * - action: Acción recomendada si hay problemas
 * 
 * ACCIONES RECOMENDADAS:
 * - Ejecutar install.php si no hay tablas
 * - Verificar permisos si hay errores de conexión
 * - Revisar estructura si faltan tablas críticas
 * 
 * @author Sistema Municipal
 * @version 1.0
 * @since 2026
 */

require_once __DIR__ . '/../config/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');

try {
    require_once __DIR__ . '/../config/db.php';

    $pdo = getDB();
    
    // Listar todas las tablas
    $tables = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($tables)) {
        echo json_encode(['error' => 'No hay tablas en la BD', 'action' => 'Ejecutar install.php']);
        exit;
    }
    
    // Verificar que existe la tabla organizaciones
    if (!in_array('organizaciones', $tables)) {
        echo json_encode(['error' => 'Tabla "organizaciones" no existe', 'tablas_existentes' => $tables]);
        exit;
    }
    
    // Contar registros
    $count = $pdo->query("SELECT COUNT(*) FROM organizaciones")->fetchColumn();
    
    echo json_encode(['ok' => true, 'tablas' => $tables, 'organizaciones_count' => $count]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
